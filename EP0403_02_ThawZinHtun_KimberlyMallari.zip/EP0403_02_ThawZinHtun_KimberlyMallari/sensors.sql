-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 16, 2024 at 03:23 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ep0403`
--

-- --------------------------------------------------------

--
-- Table structure for table `sensors`
--

CREATE TABLE `sensors` (
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `sensor` text NOT NULL,
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sensors`
--

INSERT INTO `sensors` (`datetime`, `sensor`, `value`) VALUES
('2024-02-16 00:17:38', 'camera', 'Unknown\r\n'),
('2024-02-16 00:17:58', 'camera', 'Unknown\r\n'),
('2024-02-16 00:17:58', 'camera', 'Unknown\r\n'),
('2024-02-16 00:18:18', 'camera', 'Unknown\r\n'),
('2024-02-16 00:18:18', 'camera', 'Unknown\r\n'),
('2024-02-16 00:18:38', 'camera', 'Unknown\r\n'),
('2024-02-16 01:06:21', 'camera', 'Unknown\r\n'),
('2024-02-16 01:06:31', 'password', 'Verified\r\n'),
('2024-02-16 01:06:41', 'camera', 'Unknown\r\n'),
('2024-02-16 01:06:51', 'password', 'Verified\r\n'),
('2024-02-16 01:06:59', 'camera', 'Unknown\r\n'),
('2024-02-16 01:07:02', 'password', 'Unknown\r\n'),
('2024-02-16 01:07:19', 'camera', 'Unknown\r\n'),
('2024-02-16 01:07:19', 'camera', 'Unknown\r\n'),
('2024-02-16 01:07:22', 'password', 'Unknown\r\n'),
('2024-02-16 01:07:39', 'camera', 'Unknown\r\n'),
('2024-02-16 01:07:39', 'camera', 'Unknown\r\n'),
('2024-02-16 01:07:59', 'camera', 'Unknown\r\n'),
('2024-02-16 01:07:59', 'camera', 'Unknown\r\n'),
('2024-02-16 01:08:19', 'camera', 'Unknown\r\n'),
('2024-02-16 01:08:19', 'camera', 'Unknown\r\n'),
('2024-02-16 01:08:39', 'camera', 'Unknown\r\n'),
('2024-02-16 01:08:41', 'camera', 'Unknown\r\n'),
('2024-02-16 01:09:01', 'camera', 'Unknown\r\n'),
('2024-02-16 01:09:01', 'camera', 'Unknown\r\n'),
('2024-02-16 01:41:20', 'camera', 'unknown\r\n'),
('2024-02-16 01:41:40', 'camera', 'unknown\r\n'),
('2024-02-16 01:41:46', 'camera', 'unknown\r\n'),
('2024-02-16 01:44:41', 'camera', 'unknown\r\n'),
('2024-02-16 01:45:01', 'camera', 'unknown\r\n'),
('2024-02-16 01:45:33', 'password', 'Verified\r\n'),
('2024-02-16 01:45:43', 'camera', 'unknown\r\n'),
('2024-02-16 01:45:53', 'password', 'Verified\r\n'),
('2024-02-16 01:46:03', 'camera', 'unknown\r\n'),
('2024-02-16 01:46:10', 'camera', 'unknown\r\n'),
('2024-02-16 01:47:04', 'password', 'Verified\r\n'),
('2024-02-16 01:47:24', 'password', 'Verified\r\n'),
('2024-02-16 01:47:43', 'camera', 'unknown\r\n'),
('2024-02-16 01:48:18', 'camera', 'unknown\r\n'),
('2024-02-16 01:48:27', 'password', 'Verified\r\n'),
('2024-02-16 01:48:38', 'camera', 'unknown\r\n'),
('2024-02-16 01:48:47', 'password', 'Verified\r\n'),
('2024-02-16 01:49:21', 'camera', 'kimberly'),
('2024-02-16 01:49:41', 'camera', 'kimberly'),
('2024-02-16 01:49:41', 'password', 'Verified\r\n'),
('2024-02-16 01:49:42', 'camera', 'kimberly\r\n'),
('2024-02-16 01:50:01', 'password', 'Verified\r\n'),
('2024-02-16 01:50:02', 'camera', 'kimberly\r\n'),
('2024-02-16 01:50:03', 'camera', 'kimberly\r\n'),
('2024-02-16 01:50:23', 'camera', 'kimberly\r\n'),
('2024-02-16 01:50:23', 'camera', 'kimberly\r\n'),
('2024-02-16 01:50:43', 'camera', 'kimberly\r\n'),
('2024-02-16 01:50:44', 'camera', 'kimberly\r\n'),
('2024-02-16 01:50:52', 'camera', 'Unknown'),
('2024-02-16 01:51:12', 'camera', 'Unknown'),
('2024-02-16 01:53:46', 'camera', 'kimberly\r\n'),
('2024-02-16 01:54:06', 'camera', 'kimberly\r\n'),
('2024-02-16 01:54:07', 'camera', 'kimberly\r\n'),
('2024-02-16 01:54:08', 'password', 'Unknown\r\n'),
('2024-02-16 01:54:27', 'camera', 'kimberly\r\n'),
('2024-02-16 01:54:28', 'camera', 'kimberly\r\n'),
('2024-02-16 01:54:28', 'password', 'Unknown\r\n'),
('2024-02-16 01:54:48', 'camera', 'kimberly\r\n'),
('2024-02-16 01:54:49', 'camera', 'kimberly\r\n'),
('2024-02-16 01:55:09', 'camera', 'kimberly\r\n'),
('2024-02-16 01:55:10', 'camera', 'kimberly\r\n'),
('2024-02-16 01:59:28', 'camera', 'kimberly\r\n'),
('2024-02-16 01:59:48', 'camera', 'kimberly\r\n'),
('2024-02-16 01:59:48', 'camera', 'unknown (failed)\r\n'),
('2024-02-16 02:00:08', 'camera', 'unknown (failed)\r\n'),
('2024-02-16 02:02:22', 'camera', 'rushh\r\n'),
('2024-02-16 02:02:42', 'camera', 'rushh\r\n'),
('2024-02-16 02:02:43', 'camera', 'rushh\r\n'),
('2024-02-16 02:03:03', 'camera', 'rushh\r\n'),
('2024-02-16 02:03:03', 'camera', 'rushh\r\n'),
('2024-02-16 02:03:23', 'camera', 'rushh\r\n'),
('2024-02-16 02:03:24', 'camera', 'kimberly\r\n'),
('2024-02-16 02:03:44', 'camera', 'kimberly\r\n'),
('2024-02-16 02:03:44', 'camera', 'unknown_16_02_2024-10_03_27\r\n'),
('2024-02-16 02:04:04', 'camera', 'unknown_16_02_2024-10_03_27\r\n'),
('2024-02-16 02:08:37', 'camera', 'kimberly\r\n'),
('2024-02-16 02:08:47', 'password', 'Unknown\r\n'),
('2024-02-16 02:08:57', 'camera', 'kimberly\r\n'),
('2024-02-16 02:09:07', 'password', 'Unknown\r\n'),
('2024-02-16 02:09:15', 'camera', 'unknown_16_02_2024-10_08_39\r\n'),
('2024-02-16 02:09:35', 'camera', 'unknown_16_02_2024-10_08_39\r\n'),
('2024-02-16 02:10:47', 'camera', 'unknown_16_02_2024-10_08_39\r\n'),
('2024-02-16 02:11:07', 'camera', 'unknown_16_02_2024-10_08_39\r\n'),
('2024-02-16 02:12:07', 'camera', 'kimberly\r\n'),
('2024-02-16 02:12:27', 'camera', 'kimberly\r\n'),
('2024-02-16 02:13:07', 'camera', 'kimberly\r\n'),
('2024-02-16 02:13:27', 'camera', 'kimberly\r\n'),
('2024-02-16 02:14:04', 'camera', 'kimberly'),
('2024-02-16 02:14:24', 'camera', 'kimberly'),
('2024-02-16 02:15:11', 'camera', 'kimberly\r\n'),
('2024-02-16 02:15:31', 'camera', 'kimberly\r\n'),
('2024-02-16 02:15:31', 'camera', 'unknown_16_02_2024-10_03_04\r\n'),
('2024-02-16 02:15:51', 'camera', 'unknown_16_02_2024-10_03_04\r\n'),
('2024-02-16 02:15:51', 'camera', 'kimberly\r\n'),
('2024-02-16 02:16:11', 'camera', 'kimberly\r\n'),
('2024-02-16 02:16:23', 'camera', 'rushh\r\n'),
('2024-02-16 02:16:43', 'camera', 'rushh\r\n'),
('2024-02-16 02:16:43', 'camera', 'kimberly\r\n'),
('2024-02-16 02:17:03', 'camera', 'kimberly\r\n'),
('2024-02-16 02:17:03', 'camera', 'kimberly\r\n'),
('2024-02-16 02:17:23', 'camera', 'kimberly\r\n'),
('2024-02-16 02:17:24', 'camera', 'rushh\r\n'),
('2024-02-16 02:17:44', 'camera', 'rushh\r\n'),
('2024-02-16 02:17:45', 'camera', 'kimberly\r\n'),
('2024-02-16 02:18:05', 'camera', 'kimberly\r\n'),
('2024-02-16 02:18:10', 'camera', 'kimberly\r\n'),
('2024-02-16 02:18:30', 'camera', 'kimberly\r\n'),
('2024-02-16 02:18:58', 'camera', 'rushh\r\n'),
('2024-02-16 02:19:18', 'camera', 'rushh\r\n'),
('2024-02-16 02:19:25', 'camera', 'kimberly\r\n'),
('2024-02-16 02:19:45', 'camera', 'kimberly\r\n'),
('2024-02-16 02:20:02', 'camera', 'kimberly\r\n'),
('2024-02-16 02:20:22', 'camera', 'kimberly\r\n'),
('2024-02-16 02:20:24', 'camera', 'rushh\r\n'),
('2024-02-16 02:20:44', 'camera', 'rushh\r\n'),
('2024-02-16 02:20:45', 'camera', 'kimberly\r\n'),
('2024-02-16 02:21:05', 'camera', 'kimberly\r\n'),
('2024-02-16 02:21:05', 'camera', 'kimberly\r\n'),
('2024-02-16 02:21:25', 'camera', 'kimberly\r\n'),
('2024-02-16 02:21:26', 'camera', 'unknown_16_02_2024-10_03_04\r\n'),
('2024-02-16 02:21:46', 'camera', 'unknown_16_02_2024-10_03_04\r\n'),
('2024-02-16 02:21:46', 'camera', 'kimberly\r\n'),
('2024-02-16 02:22:06', 'camera', 'kimberly\r\n'),
('2024-02-16 02:22:07', 'camera', 'kimberly\r\n'),
('2024-02-16 02:22:27', 'camera', 'kimberly\r\n'),
('2024-02-16 02:22:28', 'camera', 'kimberly\r\n'),
('2024-02-16 02:22:48', 'camera', 'kimberly\r\n'),
('2024-02-16 02:24:10', 'camera', 'kimberly\r\n'),
('2024-02-16 02:24:30', 'camera', 'kimberly\r\n'),
('2024-02-16 02:25:34', 'camera', 'unknown_16_02_2024-10_17_28\r\n'),
('2024-02-16 02:25:54', 'camera', 'unknown_16_02_2024-10_17_28\r\n'),
('2024-02-16 02:25:54', 'camera', 'unknown_16_02_2024-10_17_28\r\n'),
('2024-02-16 02:26:14', 'camera', 'unknown_16_02_2024-10_17_28\r\n'),
('2024-02-16 02:26:14', 'camera', 'unknown_16_02_2024-10_22_15\r\n'),
('2024-02-16 02:26:34', 'camera', 'unknown_16_02_2024-10_22_15\r\n'),
('2024-02-16 02:26:34', 'camera', 'unknown (failed)\r\n'),
('2024-02-16 02:26:54', 'camera', 'unknown (failed)\r\n'),
('2024-02-16 02:26:54', 'camera', 'unknown (failed)\r\n'),
('2024-02-16 02:27:14', 'camera', 'unknown (failed)\r\n'),
('2024-02-16 02:27:14', 'camera', 'unknown (failed)\r\n'),
('2024-02-16 02:27:34', 'camera', 'unknown (failed)\r\n'),
('2024-02-16 02:27:41', 'password', 'Unknown\r\n'),
('2024-02-16 02:28:01', 'password', 'Unknown\r\n'),
('2024-02-16 02:28:16', 'camera', 'unknown_16_02_2024-10_22_15\r\n'),
('2024-02-16 02:28:36', 'camera', 'unknown_16_02_2024-10_22_15\r\n'),
('2024-02-16 02:28:37', 'camera', 'kimberly\r\n'),
('2024-02-16 02:28:56', 'password', 'Unknown\r\n'),
('2024-02-16 02:28:57', 'camera', 'kimberly\r\n'),
('2024-02-16 02:28:57', 'camera', 'kimberly\r\n'),
('2024-02-16 02:29:16', 'password', 'Unknown\r\n'),
('2024-02-16 02:29:17', 'camera', 'kimberly\r\n'),
('2024-02-16 02:29:17', 'camera', 'unknown_16_02_2024-10_28_39\r\n'),
('2024-02-16 02:29:33', 'password', 'Verified\r\n'),
('2024-02-16 02:29:37', 'camera', 'unknown_16_02_2024-10_28_39\r\n'),
('2024-02-16 02:29:53', 'password', 'Verified\r\n'),
('2024-02-16 02:31:27', 'camera', 'steve\r\n'),
('2024-02-16 02:31:47', 'camera', 'steve\r\n'),
('2024-02-16 02:31:48', 'camera', 'kimberly\r\n'),
('2024-02-16 02:32:08', 'camera', 'kimberly\r\n'),
('2024-02-16 02:32:08', 'camera', 'rushh\r\n'),
('2024-02-16 02:32:28', 'camera', 'rushh\r\n'),
('2024-02-16 02:35:57', 'password', 'Unknown\r\n');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
