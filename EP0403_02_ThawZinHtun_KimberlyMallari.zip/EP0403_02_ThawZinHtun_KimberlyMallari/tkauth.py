from tkinter import *  # Tkinter
from time import sleep, strftime

class GUITemplate:  # TKINTER P1: GUI
	data, root = [], None

	def __init__(self):
		print("Init doesn't allow returns.")

	def __new__(cls):
		cls.root = Tk()
		cls.root.maxsize(600, 200)
		cls.root.geometry("600x200")
		distasteful_font = ("Comic Sans MS", 32, "bold")

		v1 = StringVar()

		Label(cls.root, width=20, text="Enter Password", font=distasteful_font).pack(anchor=S, pady=3)
		e1 = Entry(cls.root, width=20, font=distasteful_font, bd=5, textvariable=v1)
		e1.insert('0', "")
		e1.pack(anchor=S)

		Button(cls.root, font=distasteful_font, width=5, height=1, text=" Submit ", command=cls.root.destroy).pack(anchor=S)
		cls.root.mainloop()

		data = [v1.get()]
		return data



def app_thread():  # TKINTER P2: THREAD, appears behind :P
	t = 5
	while (t > 0): 
		try:
			new_data = GUITemplate()
			new_data = list(new_data)
			# you can print the data or not.
			password = new_data[0]
			if (password == "secretword"):
				print("Verified")
				return
			# else:
			# 	print("Unknown")
			
		except:
			print("Failed to update data.")
		sleep(0.05)
		t -= 1
	if (t == 0): # five times exceeded
		print("Unknown")


app_thread()
