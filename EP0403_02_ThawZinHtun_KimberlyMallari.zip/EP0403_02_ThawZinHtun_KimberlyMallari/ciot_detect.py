# C:\Users\User\.node-red
from PIL import Image, ImageOps
import PIL
import tensorflow as tf

import cv2
import numpy as np
import os
import glob
import sys
from time import sleep, strftime

label = ''
images = 5
shot_time_list = []

frame = None

def import_and_predict(image_data, model):
    
        size = (75,75)    
        image = ImageOps.fit(image_data, size, Image.ANTIALIAS)
        image = image.convert('RGB')
        image = np.asarray(image)
        image = (image.astype(np.float32) / 255.0)

        img_reshape = image[np.newaxis,...]

        # prediction = model.predict(img_reshape)
        prediction = model.predict(img_reshape,verbose=0)
        
        return prediction

# model = tf.keras.models.load_model('C:\Python\ciot\my_model.hdf5')
model = tf.keras.models.load_model(
r"C:\Users\User\AppData\Local\Programs\Python\ciot\my_model.hdf5")

    
cap = cv2.VideoCapture(0)

if (not cap.isOpened()):
    cap.open()
frame_width = int(cap.get(3)) 
frame_height = int(cap.get(4))
size = (frame_width, frame_height) 

file_path = "./captured_images"
_paths = [f'{file_path}']
for _path in _paths:
	if not os.path.exists(_path):
		os.makedirs(_path)
	else:  # remove for now
		files = glob.glob(f'{_path}/*')
		for f in files:
			os.remove(f)
		#print('Removed!')
store_path = "./stored_images"
if not os.path.exists(store_path):
    os.makedirs(store_path)


shot_time = strftime("%d_%m_%Y-%H_%M_%S")
out = None
now_recording = 0
while(cap.isOpened()):
    ret, original = cap.read()

    frame = cv2.resize(original, (224, 224))

    shot_time = strftime("%d_%m_%Y-%H_%M_%S")
    cv2.imwrite(filename=f'{file_path}/img_{shot_time}.jpg', img=original)
    image = Image.open(f'{file_path}/img_{shot_time}.jpg')
    shot_time_list.append(shot_time)

    # Delete excess images.
    if len(shot_time_list) > images:  # len(os.listdir('./static/snapshots/') to confirm image count in folder
        # Limit Number of images
        #print(shot_time_list)
        try:
            os.remove(f'{file_path}/img_{shot_time_list[0]}.jpg')
        except:
            # print("Oops! A picture slipped away") # how to remove this eh
            pass
        shot_time_list.pop(0)
        # print("now",shot_time_list)
    

    # Display the predictions
    # print("ImageNet ID: {}, Label: {}".format(inID, label))
    prediction = import_and_predict(image, model)
    #print(prediction)
    if np.argmax(prediction) == 0:
        predict="Andy"
    elif np.argmax(prediction) == 1:
        predict="Joe"
    else:
        predict="Unknown"

    

    if (predict != "Unknown") and (out != None): # end recording
       # print("========= Ending Recording =========")
        now_recording = 0
        out.release()
        out = None
    if (predict == "Unknown"):
        # false <UNKNOWN! - start recording> true - save frame <KNOWN PERSON - end recording> false
        if (now_recording == 0): # first time
            # print("========= Starting Recording =========")
            # out = cv2.VideoWriter(f'{store_path}/vid_{shot_time}.avi', 0, 20.0, (640,480))
            #out = cv2.VideoWriter(f'{store_path}/vid_{shot_time}.avi',
            #    cv2.VideoWriter_fourcc(*"MJPG"), 30,(640,480))
            out = cv2.VideoWriter(f'{store_path}/vid_{shot_time}.avi',  
                         cv2.VideoWriter_fourcc(*'MJPG'), 
                         10, size) 
            print(f'{store_path}/vid_{shot_time}.avi')

            now_recording = 1
        elif (now_recording == 1): # saving
            # print("== Next Frame ==", ret)
            out.write(original)
        #image2 = image.copy()
        #image2.save(f'{store_path}/img_{shot_time}.jpg')

    
       
    
    cv2.putText(original, predict, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
    cv2.imshow("Classification", original)

    print(predict)
    sys.stdout.flush()
    # console.log()
    if (now_recording == 0):
        sleep(1)
    else:
        sleep(0.1)

    if (cv2.waitKey(1) & 0xFF == ord('q')):
        break


if (out !=None):
    out.release()
cap.release()
frame = None
cv2.destroyAllWindows()
sys.exit()
