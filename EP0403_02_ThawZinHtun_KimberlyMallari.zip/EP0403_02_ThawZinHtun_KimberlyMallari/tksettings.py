from tkinter import *  # Tkinter
from time import sleep, strftime

class GUITemplate:  # TKINTER P1: GUI
	data, root = [], None

	def __init__(self):
		print("Init doesn't allow returns.")

	def __new__(cls):
		cls.root = Tk()
		cls.root.geometry("250x750")
		distasteful_font = ("Comic Sans MS", 10, "bold")

		v1 = StringVar()
		v2 = IntVar()
		v3 = IntVar()

		Label(cls.root, text="File path:", font=distasteful_font).pack(anchor=W, pady=3)
		e1 = Entry(cls.root, bd=5, textvariable=v1)
		e1.insert('0', "./")
		e1.pack(anchor=W)
		Label(cls.root, text="Time between pictures:", font=distasteful_font).pack(anchor=W)
		e2 = Entry(cls.root, bd=5, textvariable=v2)
		e2.insert('0', '1')
		e2.pack(anchor=W)
		Label(cls.root, text="Max snapshots:", font=distasteful_font).pack(anchor=W)
		e3 = Entry(cls.root, bd=5, textvariable=v3)
		e3.insert('1', '5')
		e3.pack(anchor=W)
		b1 = IntVar()
		b2 = IntVar()
		b3 = IntVar()
		b4 = IntVar()
		b5 = IntVar()
		Label(cls.root, text="Alarm", font=distasteful_font).pack(anchor=W)
		Radiobutton(cls.root, text="Unchanged", variable=b1, value=0).pack(anchor=W)
		Radiobutton(cls.root, text="OFF", variable=b1, value=1).pack(anchor=W)
		Radiobutton(cls.root, text="ON", variable=b1, value=2).pack(anchor=W)
		Radiobutton(cls.root, text="TRIGGER", variable=b1, value=3).pack(anchor=W)
		Label(cls.root, text="Lights", font=distasteful_font).pack(anchor=W)
		Radiobutton(cls.root, text="Unchanged", variable=b2, value=0).pack(anchor=W)
		Radiobutton(cls.root, text="OFF", variable=b2, value=1).pack(anchor=W)
		Radiobutton(cls.root, text="ON", variable=b2, value=2).pack(anchor=W)
		Label(cls.root, text="Fan", font=distasteful_font).pack(anchor=W)
		Radiobutton(cls.root, text="Unchanged", variable=b3, value=0).pack(anchor=W)
		Radiobutton(cls.root, text="OFF", variable=b3, value=1).pack(anchor=W)
		Radiobutton(cls.root, text="ON", variable=b3, value=2).pack(anchor=W)

		Label(cls.root, text="Door", font=distasteful_font).pack(anchor=W)
		Radiobutton(cls.root, text="Unchanged", variable=b4, value=0).pack(anchor=W)
		Radiobutton(cls.root, text="CLOSE", variable=b4, value=1).pack(anchor=W)
		Radiobutton(cls.root, text="OPEN", variable=b4, value=2).pack(anchor=W)
		Label(cls.root, text="Windows", font=distasteful_font).pack(anchor=W)
		Radiobutton(cls.root, text="Unchanged", variable=b5, value=0).pack(anchor=W)
		Radiobutton(cls.root, text="CLOSE", variable=b5, value=1).pack(anchor=W)
		Radiobutton(cls.root, text="OPEN", variable=b5, value=2).pack(anchor=W)

		Button(cls.root, text="Submit", command=cls.root.destroy).pack(anchor=S)
		cls.root.mainloop()

		data = [v1.get(), v2.get(), v3.get(), b1.get(), b2.get(), b3.get(), b4.get(), b5.get()]
		return data


import json
def app_thread():  # TKINTER P2: THREAD, appears behind :P
	try:
		# https://www.w3schools.com/js/js_json_parse.asp
		new_data = GUITemplate()
		new_data = list(new_data)
		print("{")
		s = 0
		for x in new_data:
			print("\""+str(s)+"\": \""+str(x)+"\"")
			if (s+1 >= len(new_data)):
				print('}')
			else:
				print(",")
			s += 1
		# print("}")

		
		# print(json.dumps(new_data))
	except:
		print("Failed to update data.")
	sleep(0.05)


app_thread()
