# def sayHELLO():
# 	return "test";

# print(sayHELLO());
# print("WHAT\nYES");
import sys
import os
import glob
file_path = "./stored_images"
_paths = [f'{file_path}']
for _path in _paths:
	print('Removing...')
	if os.path.exists(_path): # remove
		files = glob.glob(f'{_path}/*')
		for f in files:
			os.remove(f)
		print('Removed!')
