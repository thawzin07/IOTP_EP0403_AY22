import os
import requests
from options import Options
import cv2
from tkinter import *  # Tkinter
from time import sleep, strftime

class GUITemplate:  # TKINTER P1: GUI
	data, root = [], None

	def __init__(self):
		print("Init doesn't allow returns.")

	def __new__(cls):
		cls.root = Tk()
		cls.root.maxsize(600, 200)
		cls.root.geometry("600x200")
		distasteful_font = ("Comic Sans MS", 32, "bold")

		v1 = StringVar()

		Label(cls.root, width=20, text="Enter Name", font=distasteful_font).pack(anchor=S, pady=3)
		e1 = Entry(cls.root, width=20, font=distasteful_font, bd=5, textvariable=v1)
		e1.insert('0', "")
		e1.pack(anchor=S)

		Button(cls.root, font=distasteful_font, width=5, height=1, text=" Submit ", command=cls.root.destroy).pack(anchor=S)
		cls.root.mainloop()

		data = v1.get()
		return data






def register_face(img_path, user_id):
    opts = Options()
    
    filepath = f"C:/Users/User/Faces/{img_path}"
    # filepath = f"C:/Users/User/AppData/Local/Programs/Python/ciot/Faces/{img_path}"
    print("What")
    image_data = open(filepath, "rb").read()
    print("the")
    response = requests.post(opts.endpoint("vision/face/register"),
                             files={"image": image_data},
                             data={"userid": user_id}).json()
    print("hyuk")
    print(f"Registration response: {response}")
    # Registration response: {'success': True, 'message': 'face added', 'inferenceMs': 60, 'processMs': 85, 'moduleId': 'FaceProcessing', 'moduleName': 'Face Processing', 'code': 200, 'command': 'register', 'executionProvider': 'CUDA', 'canUseGPU': True, 'statusData': {'successfulInferences': 943, 'failedInferences': 0, 'numInferences': 943, 'numItemsFound': 872, 'averageInferenceMs': 29.83032873806999}, 'analysisRoundTripMs': 91, 'processedBy': 'localhost'}


new_data = "Unknown"
try:
    new_data = GUITemplate()
    # new_data = list(new_data)
    # print(new_data)
except:
    sleep(1)
sleep(0.05)


opened = False
def camera_capture(user_id):
    cap = cv2.VideoCapture(0)
    # if not cap.isOpened():
    #     opened = True
        # print("Error: Could not open camera.")
        # return None

    # Capture a frame
    ret, frame = cap.read()
    # Save the captured frame to a file
    img_path = user_id+"_camera_capture.jpg"
    cv2.imwrite("./Faces/"+img_path, frame)
    # Release the camera
    # if (opened):
    cap.release()

    return img_path

# register_face("chris-hemsworth-1.jpg", "Chris Hemsworth")
# register_face("Robert-Downey-Jr-1.jpg", "Robert Downey Jr.")
# register_face("scarlett-johanson-1.jpg", "Scarlett Johanson")
img_path = camera_capture(new_data)
print( new_data)
register_face(img_path, new_data)
