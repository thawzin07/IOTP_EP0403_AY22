import os
try:
	os.system(r"start C:\Users\User\AppData\Local\Programs\Python\ciot\alarm.mp3")
	
except:
	print("Error")

# note: require subprocess for killing media player task