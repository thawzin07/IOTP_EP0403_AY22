# C:\Users\User\.node-red
from PIL import Image, ImageOps
import PIL
import tensorflow as tf

import cv2
import numpy as np
import os
import glob
import sys
from time import sleep, strftime

import requests
from options import Options # a file




label = ''
images = 5
shot_time_list = []

frame = None


# using existing image    
def auto_register_face(img_path, t, opts):
    # filepath = os.path.join(opts.imageDir + "/Faces", img_path)
    # filepath = f"C:/Users/User/AppData/Local/Programs/Python/ciot/captured_images/{img_path
    filepath = f"C:/Users/User/captured_images/{img_path}"
    image_data = open(filepath, "rb").read()
    response = requests.post(opts.endpoint("vision/face/register"),
                             files={"image": image_data},
                             data={"userid": "unknown_"+str(t)}).json()

    print(f"Registration response: {response}")

    
def recognize_face(img_path, opts):
     # filepath = os.path.join(opts.imageDir + "/Faces", img_path)
    filepath = f"C:/Users/User/captured_images/{img_path}"
    # filepath = f"C:/Users/User/AppData/Local/Programs/Python/ciot/captured_images/{img_path}"
   
    image_data = open(filepath, "rb").read()

    response = requests.post(opts.endpoint("vision/face/recognize"),
                             files={"image": image_data},
                             data={"min_confidence": 0.6}).json()
    try:
        for user in response["predictions"]:
            user_id = user["userid"]
            # print(f'Recognized as: {user_id}')
            return user_id
    except:
        return "unknown (failed)"

def delete_face(user_id):
    opts = Options()

    response = requests.post(opts.endpoint("vision/face/delete"),
                             data={"userid": user_id}).json()

    print(f"Deletion response: {response}")


cap = cv2.VideoCapture(0)
frame_index = 0
predictions = {}
skip_frame  = 5

if (not cap.isOpened()):
    cap.open()
frame_width = int(cap.get(3)) 
frame_height = int(cap.get(4))
size = (frame_width, frame_height) 

file_path = "./captured_images"
_paths = [f'{file_path}']
for _path in _paths:
	if not os.path.exists(_path):
		os.makedirs(_path)
	else:  # remove for now
		files = glob.glob(f'{_path}/*')
		for f in files:
			os.remove(f)
		#print('Removed!')
store_path = "./stored_images"
if not os.path.exists(store_path):
    os.makedirs(store_path)







sus_dict = {}




shot_time = strftime("%d_%m_%Y-%H_%M_%S")
out = None
now_recording = 0
opts = Options()  # Initialize Options class here
while(True):
    
    ret, original = cap.read()

    frame = cv2.resize(original, (224, 224))

    # img_path = f"./Graphics/{user_id}_camera_capture.jpg"
    
    shot_time = strftime("%d_%m_%Y-%H_%M_%S")
    img_path = f'{file_path}/img_{shot_time}.jpg'
    img_loc = f'img_{shot_time}.jpg'
    # cv2.imwrite(img_path, frame)    
    cv2.imwrite(filename=img_path, img=original)
    image = Image.open(f'{file_path}/img_{shot_time}.jpg')
    shot_time_list.append(shot_time)

    # Delete excess images.
    if len(shot_time_list) > images:  # len(os.listdir('./static/snapshots/') to confirm image count in folder
        # Limit Number of images
        #print(shot_time_list)
        try:
            os.remove(f'{file_path}/img_{shot_time_list[0]}.jpg')
        except:
            # print("Oops! A picture slipped away") # how to remove this eh
            pass
        shot_time_list.pop(0)
        # print("now",shot_time_list)
    # print("Predicting...")

    # retval, new_frame = cv2.imencode('.jpg', original)
    predict = recognize_face(img_loc, opts)

    # Display the predictions


    if (predict.find("unknown") == -1) and (out != None): # end recording
       # print("========= Ending Recording =========")
        now_recording = 0
        out.release()
        out = None
    if (predict.find("unknown") != -1): # is unknown person
        # false <UNKNOWN! - start recording> true - save frame <KNOWN PERSON - end recording> false
        if (now_recording == 0): # first time
            # print("========= Starting Recording =========")
            current_path = f'{store_path}/vid_{shot_time}.avi'
            if (predict == "unknown (failed)" or predict == "unknown"):
                auto_register_face(img_loc, shot_time, opts)
                sus_dict["unknown_"+str(shot_time)] = 0
                current_path = f'{store_path}/sus_vid_{shot_time}.avi'
            

            out = cv2.VideoWriter(current_path,  
                         cv2.VideoWriter_fourcc(*'MJPG'), 
                         10, size) 
            # print(f'{store_path}/vid_{shot_time}.avi')
            now_recording = 1
        elif (now_recording == 1): # saving
            # print("== Next Frame ==", ret)
            # print("DICTIONARRRRRREEEE", sus_dict)
            # print("shottime", str(shot_time))
            # print("Val", sus_dict["unknown_"+str(shot_time)])
            

            # sus_dict["unknown_"+str(shot_time)] = sus_dict["unknown_"+str(shot_time)] + 1
            out.write(original)
            # print("/vid chances" + sus_dict["unknown_"+shot_time])
            # if (sus_dict["unknown_"+str(shot_time)] > 1000):
            #     print("Serious Warning unknown")
        #image2 = image.copy()
        #image2.save(f'{store_path}/img_{shot_time}.jpg')
            
    cv2.putText(original, predict, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
    cv2.imshow("Classification", original)

    print(predict)
    sys.stdout.flush()
    # console.log()
    if (now_recording == 0):
        sleep(1)
    else:
        sleep(0.1)

    if (cv2.waitKey(1) & 0xFF == ord('q')):
        break


if (out !=None):
    out.release()
cap.release()
frame = None
cv2.destroyAllWindows()
sys.exit()
